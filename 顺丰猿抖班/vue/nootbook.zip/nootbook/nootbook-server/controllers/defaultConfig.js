const config = {
  dataBase: {
    DATABASE: "notebook",
    USERNAME: 'root',
    PASSWORD: '980112tc',
    PORT: '3306',
    HOST: 'localhost'
  }
}

module.exports = config