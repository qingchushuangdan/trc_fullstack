module.exports = {
  port: 3000,
  db: 'mongodb://localhost:27017/dai-ke', // 数据库
  saltTimes: 3 // 加盐的次数(加密)
}